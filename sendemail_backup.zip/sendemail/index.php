<?php
 if(isset($_POST['submit']))
 {
    $name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$query = $_POST['message'];
	$email_from = $name.'<'.$email.'>';

 $sendtoemail="russell@sandrtechnology.com";
 $subject="Web Visitor Message";
 $headers  = 'MIME-Version: 1.0' . "\r\n";
 $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 $headers .= "From: ".$email_from."\r\n";
 $message="	  
 	   
		<strong>Name:</strong>
		$name 	   
		<br>
		<strong>Phone Number:</strong>
		$phone 
		<br>
		<strong>Email Address:</strong>
		$email 		 
		<br><br>
		<strong>Message:</strong>
		$query 	   
      
   ";
	if(mail($sendtoemail,$subject,$message,$headers))
		//header("Location:../contact-confirm.html");
		$response_message = "Thank you - your message has been sent! Someone will reach out to your inquiry within 24 hours.";
		//header("Location: http://www.dallascablecutters.com/#contact");
		//echo "<h2>Email sent.</h2>";
	else
		//header("Location:../contact-failed.html");
		//contact:-your-email@your-domain.com
		$response_message = "We're sorry, unfortunately we were unable to send your message. Please ensure all fields are filled out properly and try again.";
		//header("Location: http://www.dallascablecutters.com/#contact");
		//echo "<h2>Email NOT sent.</h2>";
 }

echo $response_message;
//sleep (5);
//header("Location:../#contact");
?>